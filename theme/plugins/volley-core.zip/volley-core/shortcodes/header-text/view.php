<?php 

extract( $atts );

$this->generate_css();


?>
<div class="header-module">
	<?php $this->get_content() ?>
</div>