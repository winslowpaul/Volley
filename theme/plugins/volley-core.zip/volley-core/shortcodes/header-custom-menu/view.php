<?php 

extract( $atts );


?>
<div class="header-module">
	<?php $this->get_menu() ?>
</div>