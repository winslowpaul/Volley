<div class="header-module">
<?php

$located = locate_template( 'templates/header/header-cart.php' );
include $located;

?>
</div>